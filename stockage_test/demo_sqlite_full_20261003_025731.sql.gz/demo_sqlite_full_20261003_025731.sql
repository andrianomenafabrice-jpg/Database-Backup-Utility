BEGIN TRANSACTION;
CREATE TABLE clients (id INTEGER PRIMARY KEY, nom TEXT, ville TEXT);
INSERT INTO "clients" VALUES(1,'Rakoto','Antananarivo');
INSERT INTO "clients" VALUES(2,'Rasoa','Toamasina');
INSERT INTO "clients" VALUES(3,'Hery','Fianarantsoa');
INSERT INTO "clients" VALUES(4,'Nirina','Mahajanga');
COMMIT;
